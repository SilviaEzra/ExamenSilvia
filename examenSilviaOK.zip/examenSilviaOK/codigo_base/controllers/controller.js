"use strict";

function crearEspec() {
    const selectElement = document.getElementById('espec');
    const selectedOptionValue = selectElement.selectedOptions[0].value;

    if (alumnosPorEspecializacion[selectedOptionValue]) {
        
        const especializacion = alumnosPorEspecializacion[selectedOptionValue];

        console.log("Especialización seleccionada:", especializacion);

        
        const numAlumnosInput = document.getElementById('numalumnos');
        const numAlumnos = parseInt(numAlumnosInput.value);
        const errorNumberAl = document.getElementById('errorNumberAl');

        if (numAlumnos <= 0 || isNaN(numAlumnos)) {
            errorNumberAl.style.display = 'block';
            numAlumnosInput.classList.add('is-invalid');
            
        } else {
            errorNumberAl.style.display = 'none';
            numAlumnosInput.classList.remove('is-invalid');
            numAlumnosInput.classList.add('is-valid');
        }
    } else {
        console.log("La especialización seleccionada no existe.");
    }

    const createWheelForm = document.getElementById('form');
    createWheelForm.style.display = 'block';
}


function showAlumn() { 
    const nombre = document.getElementById("nom");
    nombre.innerText = "Nombre: " + alumno.nombre;

    const apellidos = document.getElementById("apellidos");
    apellidos.innerText = "Apellidos: " + alumno.apellidos;

    const dni = document.getElementById("DNI");
    dni.innerText = "DNI: " + alumno.DNI;

    const poblacion = document.getElementById("poblacion");
    poblacion.innerText = "Población: " + alumno.poblacion;

    const especDiv = document.getElementById("especializacion");
    especDiv.innerText = "Especialización: " + especializacion;

}

    

function mostrarAlumnos() {
    const container = document.getElementById("alumnos-container");

    
    container.innerHTML = "";

    
    Object.entries(alumnosPorEspecializacion).forEach(([espec, alumnosEnEspec]) => {
       
        alumnosEnEspec.forEach((alumn) => {
            const alumnoDiv = document.createElement("div");
            alumnoDiv.classList.add("alumno");

          
            alumnoDiv.innerHTML = `
                <div class="row">
                    <div class="col create-car-output">
                        <p class="especializacion"><b>Especialización:</b> ${espec}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="nombre"><b>Nombre:</b> ${alumn.nombre}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="apellidos"><b>Apellidos:</b> ${alumn.apellidos}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="dni"><b>DNI:</b> ${alumn.dni}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="poblacion"><b>Población:</b> ${alumn.poblacion}</p>
                    </div>
                </div>
            `;

            
            container.appendChild(alumnoDiv);
        });
    });
}


    let alumnosPorEspecializacion = {
        'Angular': [],
        'PHP': [],
        'NodeJS': [],
        'Java': []
    };


    function borrarCampos() {
        document.getElementById("nom").value = ""; 
        document.getElementById("apellidos").value = "";
        document.getElementById("DNI").value = ""; 
        document.getElementById("poblacion").value = ""; 
       
    }
    
    
    function submitAlumn() {
        
        const nombre = document.getElementById(`nom`);
        const apellidos = document.getElementById(`apellidos`);
        const dni = document.getElementById(`DNI`);
        const poblacion = document.getElementById(`poblacion`);
        const numAlumnos = parseInt(document.getElementById("numalumnos").value);
        
    
        if (nombre.classList.contains("is-valid") && 
            apellidos.classList.contains("is-valid") &&
            dni.classList.contains("is-valid") &&
            poblacion.classList.contains("is-valid")) {
    
            const espec = document.getElementById('espec').value;
    
            if (alumnosPorEspecializacion[espec]) {
                const alumnosEnEspec = alumnosPorEspecializacion[espec].length;
                
                if (alumnosEnEspec < numAlumnos) {
                    const nuevoAlumno = {
                        nombre: nombre.value,
                        apellidos: apellidos.value,
                        dni: dni.value,
                        poblacion: poblacion.value,
                        espec: espec
                    };
                    alumnosPorEspecializacion[espec].push(nuevoAlumno);
                    console.log("Alumno añadido a la especialización " + espec + ".");
                    console.log("Alumnos en " + espec + ":", alumnosPorEspecializacion[espec]);
                    borrarCampos()
                    mostrarAlumnos()
                } else {
                    alert("Se ha alcanzado el límite de alumnos para la especialización " + espec + ".")
                    console.log("Se ha alcanzado el límite de alumnos para la especialización " + espec + "."); 
                    borrarCampos() 
                    
                }
            } else {
                console.log("La especialización seleccionada no es válida.");
            }
        } else {
            console.log("Por favor, complete todos los campos correctamente antes de agregar un nuevo alumno.");
        }

      
    }
    function mostrarForm() {
        var especForm = document.getElementById("create-car-form");
        var alumnForm = document.getElementById("form");
        especForm.style.display = "none";
        alumnForm.style.display = "block";
    }


    function validate(event) {
        event.preventDefault()
        
        let error = 0;
        
        let fName = document.getElementById("nom");
        let fLastN = document.getElementById("apellidos");
        let fDni = document.getElementById("DNI");
        let fAddress = document.getElementById("poblacion");
        let numAlumnos = document.getElementById('numalumnos'); 
        

        if (numAlumnos.value <= 0 || isNaN(numAlumnos.value)) { 
            error++;
            numAlumnos.classList.remove("is-valid"); 
            numAlumnos.classList.add("is-invalid");
        } else {
            numAlumnos.classList.remove("is-invalid");
            numAlumnos.classList.add("is-valid"); 
        }


        if(fName.value.length < 3 || !/^[a-zA-Z]+$/.test(fName.value)){
            error++;
            fName.classList.add("is-invalid");
            fName.classList.remove("is-valid");
        } else {
            fName.classList.add("is-valid");
            fName.classList.remove("is-invalid");
        }
    
        if (fLastN.value.length < 3 || !/^[a-zA-Z]+$/.test(fLastN.value)) {
            error++;
            fLastN.classList.add("is-invalid");
            fLastN.classList.remove("is-valid");
        } else {
            fLastN.classList.add("is-valid");
            fLastN.classList.remove("is-invalid");
        }
        
    
        if (fDni.value.length < 9 || !/^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$/i.test(fDni.value)) {
            error++;
            fDni.classList.add("is-invalid");
            fDni.classList.remove("is-valid");
        } else {
            fDni.classList.add("is-valid");
            fDni.classList.remove("is-invalid");
        }
        
        if (fAddress.value.length < 3) {
            error++;
            fAddress.classList.add("is-invalid");
            fAddress.classList.remove("is-valid");
        } else {
            fAddress.classList.add("is-valid");
            fAddress.classList.remove("is-invalid");
        }


    }
"use strict";

interface Alumno {
    nombre: string;
    apellidos: string;
    dni: string;
    poblacion: string;
}

let alumnosPorEspecializacion: { [key: string]: Alumno[] } = {
    'Angular': [],
    'PHP': [],
    'NodeJS': [],
    'Java': []
};

function crearEspec(): void {
    const selectElement = document.getElementById('espec') as HTMLSelectElement;
    const selectedOptionValue = selectElement.selectedOptions[0].value;

    if (alumnosPorEspecializacion[selectedOptionValue]) {
        const especializacion = alumnosPorEspecializacion[selectedOptionValue];
        console.log("Especialización seleccionada:", especializacion);

        const numAlumnosInput = document.getElementById('numalumnos') as HTMLInputElement;
        const numAlumnos = parseInt(numAlumnosInput.value);
        const errorNumberAl = document.getElementById('errorNumberAl');

        if (numAlumnos <= 0 || isNaN(numAlumnos)) {
            const errorNumberAl = document.getElementById('errorNumberAl');
            if (errorNumberAl) {
                errorNumberAl.style.display = 'block';
            }
            numAlumnosInput.classList.add('is-invalid');
        } else {
            const errorNumberAl = document.getElementById('errorNumberAl');
            if (errorNumberAl) {
                errorNumberAl.style.display = 'none';
            }
            numAlumnosInput.classList.remove('is-invalid');
            numAlumnosInput.classList.add('is-valid');
        }
        
        const createWheelForm = document.getElementById('form');
        if (createWheelForm) {
            createWheelForm.style.display = 'block';
        }
    }      
}

function showAlumn(alumno: Alumno, especializacion: string): void {
    const nombre = document.getElementById("nom") as HTMLParagraphElement;
    nombre.innerText = "Nombre: " + alumno.nombre;

    const apellidos = document.getElementById("apellidos") as HTMLParagraphElement;
    apellidos.innerText = "Apellidos: " + alumno.apellidos;

    const dni = document.getElementById("DNI") as HTMLParagraphElement;
    dni.innerText = "DNI: " + alumno.dni;

    const poblacion = document.getElementById("poblacion") as HTMLParagraphElement;
    poblacion.innerText = "Población: " + alumno.poblacion;

    const especDiv = document.getElementById("especializacion") as HTMLParagraphElement;
    especDiv.innerText = "Especialización: " + especializacion;
}

function mostrarAlumnos(): void {
        const container = document.getElementById("alumnos-container");
        if (!container) {
            console.error("El elemento 'alumnos-container' no fue encontrado.");
            return;
        }
        container.innerHTML = "";

    Object.entries(alumnosPorEspecializacion).forEach(([espec, alumnosEnEspec]: [string, Alumno[]]) => {
        alumnosEnEspec.forEach((alumn) => {
            const alumnoDiv = document.createElement("div");
            alumnoDiv.classList.add("alumno");

            alumnoDiv.innerHTML = `
                <div class="row">
                    <div class="col create-car-output">
                        <p class="especializacion"><b>Especialización:</b> ${espec}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="nombre"><b>Nombre:</b> ${alumn.nombre}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="apellidos"><b>Apellidos:</b> ${alumn.apellidos}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="dni"><b>DNI:</b> ${alumn.dni}</p>
                    </div>
                    <div class="col create-car-output">
                        <p class="poblacion"><b>Población:</b> ${alumn.poblacion}</p>
                    </div>
                </div>
            `;

            container.appendChild(alumnoDiv);
        });
    });
}

function borrarCampos(): void {
    (document.getElementById("nom") as HTMLInputElement).value = "";
    (document.getElementById("apellidos") as HTMLInputElement).value = "";
    (document.getElementById("DNI") as HTMLInputElement).value = "";
    (document.getElementById("poblacion") as HTMLInputElement).value = "";
}

function submitAlumn(): void {
    const nombre = document.getElementById(`nom`) as HTMLInputElement;
    const apellidos = document.getElementById(`apellidos`) as HTMLInputElement;
    const dni = document.getElementById(`DNI`) as HTMLInputElement;
    const poblacion = document.getElementById(`poblacion`) as HTMLInputElement;
    const numAlumnos = parseInt((document.getElementById("numalumnos") as HTMLInputElement).value);

    if (nombre.classList.contains("is-valid") &&
        apellidos.classList.contains("is-valid") &&
        dni.classList.contains("is-valid") &&
        poblacion.classList.contains("is-valid")) {

        const espec = (document.getElementById('espec') as HTMLSelectElement).value;

        if (alumnosPorEspecializacion[espec]) {
            const alumnosEnEspec = alumnosPorEspecializacion[espec].length;

            if (alumnosEnEspec < numAlumnos) {
                const nuevoAlumno: Alumno = {
                    nombre: nombre.value,
                    apellidos: apellidos.value,
                    dni: dni.value,
                    poblacion: poblacion.value
                };
                alumnosPorEspecializacion[espec].push(nuevoAlumno);
                console.log("Alumno añadido a la especialización " + espec + ".");
                console.log("Alumnos en " + espec + ":", alumnosPorEspecializacion[espec]);
                borrarCampos();
                mostrarAlumnos();
            } else {
                alert("Se ha alcanzado el límite de alumnos para la especialización " + espec + ".");
                console.log("Se ha alcanzado el límite de alumnos para la especialización " + espec + ".");
                borrarCampos();
            }
        } else {
            console.log("La especialización seleccionada no es válida.");
        }
    } else {
        console.log("Por favor, complete todos los campos correctamente antes de agregar un nuevo alumno.");
    }
}

function mostrarForm(): void {
    const especForm = document.getElementById("create-car-form") as HTMLElement;
    const alumnForm = document.getElementById("form") as HTMLElement;
    especForm.style.display = "none";
    alumnForm.style.display = "block";
}

function validate(event: Event): void {
    event.preventDefault();

    let error = 0;

    const fName = document.getElementById("nom") as HTMLInputElement;
    const fLastN = document.getElementById("apellidos") as HTMLInputElement;
    const fDni = document.getElementById("DNI") as HTMLInputElement;
    const fAddress = document.getElementById("poblacion") as HTMLInputElement;
    const numAlumnos = document.getElementById('numalumnos') as HTMLInputElement;

    if (numAlumnos.valueAsNumber <= 0 || isNaN(numAlumnos.valueAsNumber)) {
        error++;
        numAlumnos.classList.remove("is-valid");
        numAlumnos.classList.add("is-invalid");
    } else {
        numAlumnos.classList.remove("is-invalid");
        numAlumnos.classList.add("is-valid");
    }

    if (fName.value.length < 3 || !/^[a-zA-Z]+$/.test(fName.value)) {
        error++;
        fName.classList.add("is-invalid");
        fName.classList.remove("is-valid");
    } else {
        fName.classList.add("is-valid");
        fName.classList.remove("is-invalid");
    }

    if (fLastN.value.length < 3 || !/^[a-zA-Z]+$/.test(fLastN.value)) {
        error++;
        fLastN.classList.add("is-invalid");
        fLastN.classList.remove("is-valid");
    } else {
        fLastN.classList.add("is-valid");
        fLastN.classList.remove("is-invalid");
    }

    if (fDni.value.length < 9 || !/^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$/i.test(fDni.value)) {
        error++;
        fDni.classList.add("is-invalid");
        fDni.classList.remove("is-valid");
    } else {
        fDni.classList.add("is-valid");
        fDni.classList.remove("is-invalid");
    }

    if (fAddress.value.length < 3) {
        error++;
        fAddress.classList.add("is-invalid");
        fAddress.classList.remove("is-valid");
    } else {
        fAddress.classList.add("is-valid");
        fAddress.classList.remove("is-invalid");
    }
}

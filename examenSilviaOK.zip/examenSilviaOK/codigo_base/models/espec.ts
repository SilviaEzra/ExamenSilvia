class Espec {
    tipo: string;
    alumn: Alumno[] = [];
    numAlumnos: number;

    constructor(tipo: string, numAlumnos: number) {
        this.tipo = tipo;
        this.numAlumnos = numAlumnos;
    }

    addAlumn(alumn: Alumno): boolean {
        if (this.alumn.length < this.numAlumnos) {
            this.alumn.push(alumn);
            console.log(`Alumno añadido a la especialización ${this.tipo}.`);
            return true; // Se agregó el alumno correctamente
        } else {
            console.log(`No se pueden añadir más alumnos a la especialización ${this.tipo}. Se ha alcanzado el límite de ${this.numAlumnos} alumnos.`);
            return false; // No se pudo agregar el alumno debido al límite alcanzado
        }
    }
}

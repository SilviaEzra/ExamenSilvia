"use strict";
var alumn = /** @class */ (function () {
    function alumn(nombre, apellidos, dni, poblacion) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.poblacion = poblacion;

    }
    return alumn;
}());


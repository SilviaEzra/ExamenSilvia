"use strict";

// Definición de la clase Espec
const Espec = /** @class */ (function () {
    function Espec(tipo) {
        this.alumn = [];
        this.tipo = tipo;
    }

    // Método para agregar un alumno a la especialización
    Espec.prototype.addAlumn = function (alumn) {
        if (this.alumn.length < this.numAlumnos) {
            this.alumn.push(alumn);
            console.log("Alumno añadido a la especialización " + this.tipo + ".");
            return true; // Se agregó el alumno correctamente
            
        } else {
            console.log("No se pueden añadir más alumnos a la especialización " + this.tipo + ". Se ha alcanzado el límite de " + this.numAlumnos + " alumnos.");
            return false; // No se pudo agregar el alumno debido al límite alcanzado
        }
    };

    return Espec;
}());
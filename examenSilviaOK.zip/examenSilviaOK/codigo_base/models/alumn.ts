class Alumno {
    nombre: string;
    apellidos: string;
    dni: string;
    poblacion: string;

    constructor(nombre: string, apellidos: string, dni: string, poblacion: string) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.poblacion = poblacion;
    }
}
